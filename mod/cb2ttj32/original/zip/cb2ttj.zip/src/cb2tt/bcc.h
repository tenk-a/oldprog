#define __far far
#define _ffree farfree
#define _frealloc farrealloc
